﻿namespace EventPlannerSampleTest.Data
{
    public class ReqResData
    {

        
        public int? clients_id { get; set; }
        public int? vendor_id { get; set; }
        public int? service_id { get; set; }
        public sbyte? response { get; set; }
    }
}
