﻿using System.ComponentModel.DataAnnotations;

namespace EventPlannerSampleTest.Data
{
    public class ServicesData
    {
        
        public int vendor_id { get; set; }
        public int event_id { get; set; }
      
        
        public int? amount { get; set; }
    }
}
